<?php
// dashboard.php

session_start();

// Jika belum login, paksa ke login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Efren Reyes Web</title>
    <!-- Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Icon Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

<!-- Wrapper isi konten dan footer -->
<div class="flex-grow-1">

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navMenu">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
                    <li class="nav-item"><a href="dashboard.php" class="nav-link active">Dashboard</a></li>
                    <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                    <li class="nav-item"><a href="achievement.php" class="nav-link">Prestasi</a></li>
                    <li class="nav-item"><a href="gallery.php" class="nav-link">Galeri</a></li>
                    <li class="nav-item"><a href="tournament.php" class="nav-link">Turnamen</a></li>
                    <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
                    <li class="nav-item"><a href="merchandise.php" class="nav-link">Merchandise</a></li>
                </ul>
                <?php if (isset($_SESSION['username'])): ?>
                    <span class="navbar-text text-white me-3">
                        Halo, <?= $_SESSION['username']; ?>
                    </span>
                    <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-sm btn-outline-light">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Konten -->
    <div class="container mt-5">
        <div class="text-center mb-4">
            <h2>Selamat Datang di Dashboard</h2>
            <p class="lead">Website resmi profil legenda biliar dunia, <strong>Efren 'Bata' Reyes</strong></p>
        </div>

        <!-- Card Menu -->
        <div class="row text-center g-4">
            <div class="col-md-4">
                <a href="profile.php" class="text-decoration-none text-dark">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <i class="bi bi-person-fill display-4 text-primary"></i>
                            <h5 class="mt-3">Profil</h5>
                            <p>Informasi biografi dan latar belakang Efren Reyes.</p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-4">
                <a href="achievement.php" class="text-decoration-none text-dark">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <i class="bi bi-trophy-fill display-4 text-success"></i>
                            <h5 class="mt-3">Prestasi</h5>
                            <p>Riwayat prestasi luar biasa dalam dunia biliar.</p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-4">
                <a href="gallery.php" class="text-decoration-none text-dark">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <i class="bi bi-images display-4 text-warning"></i>
                            <h5 class="mt-3">Galeri</h5>
                            <p>Kumpulan foto dan momen spesial selama karier.</p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-4">
                <a href="tournament.php" class="text-decoration-none text-dark">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <i class="bi bi-calendar-event display-4 text-info"></i>
                            <h5 class="mt-3">Turnamen</h5>
                            <p>Daftar turnamen yang diikuti beserta hasilnya.</p>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-md-4">
                <a href="admin.php" class="text-decoration-none text-dark">
                    <div class="card shadow-sm h-100">
                        <div class="card-body">
                            <i class="bi bi-gear-fill display-4 text-danger"></i>
                            <h5 class="mt-3">Admin</h5>
                            <p>Kelola akun admin dan data pengguna website.</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div> <!-- End konten wrapper -->

<!-- Footer Sticky -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
