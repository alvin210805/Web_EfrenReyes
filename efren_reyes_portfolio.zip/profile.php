<?php
// profile.php

session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Profil Efren Reyes</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
                <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link active">Profil</a></li>
                <li class="nav-item"><a href="achievement.php" class="nav-link">Prestasi</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Galeri</a></li>
                <li class="nav-item"><a href="tournament.php" class="nav-link">Turnamen</a></li>
                <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
                <li class="nav-item"><a href="merchandise.php" class="nav-link">Merchandise</a></li>
            </ul>
            <?php if (isset($_SESSION['username'])): ?>
                <span class="navbar-text text-white me-3">
                    Halo, <?= $_SESSION['username']; ?>
                </span>
                <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm btn-outline-light">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container my-5 flex-grow-1">
    <h2 class="mb-4">Profil Efren Reyes</h2>

    <div class="row">
        <div class="col-md-4">
            <img src="efren_profile.jpg" alt="Efren Reyes" class="img-fluid rounded shadow">
        </div>
        <div class="col-md-8">
            <h4>Efren "Bata" Reyes</h4>
            <p>
                Efren Reyes, yang dijuluki <strong>"The Magician"</strong>, adalah pemain biliar legendaris asal Filipina yang telah menginspirasi jutaan orang di seluruh dunia. Lahir pada 26 Agustus 1954 di Angeles City, ia dikenal karena kemampuannya membaca permainan, pukulan tidak terduga, dan teknik sulap yang memukau di atas meja.
            </p>
            <p>
                Efren memulai kariernya dari tempat sederhana, bekerja sebagai penjaga meja biliar pada usia muda. Namun, dengan dedikasi dan kerja keras, ia berhasil menjadi pemain kelas dunia dan mengubah wajah olahraga biliar secara global. Ia telah memenangkan lebih dari 100 gelar internasional di berbagai kategori, termasuk 9-ball, 8-ball, dan one-pocket.
            </p>
            <p>
                Lebih dari sekadar juara, Efren adalah simbol ketekunan dan kecerdikan. Gayanya yang rendah hati, penuh strategi, serta kejutan tak terduga dalam permainan membuatnya dikagumi oleh lawan dan penonton di seluruh dunia. Tak heran jika ia sering dianggap sebagai pemain biliar terbaik sepanjang masa.
            </p>

            <ul class="mt-4">
                <li><strong>Nama Lengkap:</strong> Efren Manalang Reyes</li>
                <li><strong>Tanggal Lahir:</strong> 26 Agustus 1954</li>
                <li><strong>Asal:</strong> Angeles City, Pampanga, Filipina</li>
                <li><strong>Gaya Bermain:</strong> 9-ball, 8-ball, one-pocket</li>
                <li><strong>Julukan:</strong> The Magician</li>
                <li><strong>Prestasi Ikonik:</strong> Juara Dunia WPA, Hall of Fame, SEA Games Gold Medalist</li>
            </ul>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
