<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Tambah turnamen
if (isset($_POST['tambah'])) {
    $nama_turnamen = $_POST['nama_turnamen'];
    $lokasi = $_POST['lokasi'];
    $tahun  = $_POST['tahun'];
    $hasil  = $_POST['hasil'];

    $query = "INSERT INTO tournaments (nama_turnamen, lokasi, tahun, hasil)
              VALUES ('$nama_turnamen', '$lokasi', '$tahun', '$hasil')";
    mysqli_query($conn, $query);
    header("Location: tournament.php");
    exit;
}

// Hapus turnamen
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM tournaments WHERE id=$id");
    header("Location: tournament.php");
    exit;
}

// Ambil data turnamen
$where = '';
if (!empty($_GET['filter_tahun'])) {
    $tahun_filter = mysqli_real_escape_string($conn, $_GET['filter_tahun']);
    $where = "WHERE tahun = '$tahun_filter'";
} elseif (!empty($_GET['filter_lokasi'])) {
    $lokasi_filter = mysqli_real_escape_string($conn, $_GET['filter_lokasi']);
    $where = "WHERE lokasi LIKE '%$lokasi_filter%'";
}

$result = mysqli_query($conn, "SELECT * FROM tournaments $where ORDER BY tahun DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Turnamen Efren Reyes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
                <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="achievement.php" class="nav-link">Prestasi</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Galeri</a></li>
                <li class="nav-item"><a href="tournament.php" class="nav-link active">Turnamen</a></li>
                <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
                <li class="nav-item"><a href="merchandise.php" class="nav-link">Merchandise</a></li>
            </ul>
            <?php if (isset($_SESSION['username'])): ?>
                <span class="navbar-text text-white me-3">
                    Halo, <?= $_SESSION['username']; ?>
                </span>
                <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm btn-outline-light">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<main class="container my-4">
    <h3 class="mb-4">Riwayat Turnamen Efren Reyes</h3>

    <!-- Form Filter -->
    <form method="get" class="row g-2 mb-4">
        <div class="col-md-3">
            <input type="text" name="filter_lokasi" class="form-control" placeholder="Filter Lokasi" value="<?= isset($_GET['filter_lokasi']) ? $_GET['filter_lokasi'] : '' ?>">
        </div>
        <div class="col-md-3">
            <input type="number" name="filter_tahun" class="form-control" placeholder="Filter Tahun" value="<?= isset($_GET['filter_tahun']) ? $_GET['filter_tahun'] : '' ?>">
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100">Terapkan</button>
        </div>
        <div class="col-md-2">
            <a href="tournament.php" class="btn btn-secondary w-100">Reset</a>
        </div>
    </form>

    <!-- Form Tambah Turnamen -->
    <form method="post" class="row g-2 mb-4">
        <div class="col-md-3">
            <input type="text" name="nama_turnamen" class="form-control" placeholder="Nama Turnamen" required>
        </div>
        <div class="col-md-3">
            <input type="text" name="lokasi" class="form-control" placeholder="Lokasi" required>
        </div>
        <div class="col-md-2">
            <input type="number" name="tahun" class="form-control" placeholder="Tahun" required>
        </div>
        <div class="col-md-2">
            <input type="text" name="hasil" class="form-control" placeholder="Hasil" required>
        </div>
        <div class="col-md-2">
            <button type="submit" name="tambah" class="btn btn-success w-100">Tambah</button>
        </div>
    </form>

    <!-- Tabel Turnamen -->
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead class="table-dark text-center">
                <tr>
                    <th>Nama Turnamen</th>
                    <th>Lokasi</th>
                    <th>Tahun</th>
                    <th>Hasil</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody class="text-center">
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['nama_turnamen']; ?></td>
                    <td><?= $row['lokasi']; ?></td>
                    <td><?= $row['tahun']; ?></td>
                    <td><?= $row['hasil']; ?></td>
                    <td>
                        <a href="tournament.php?hapus=<?= $row['id']; ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Hapus data ini?')">
                            Hapus
                        </a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</main>

<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
