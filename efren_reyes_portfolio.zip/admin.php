<?php
// admin.php

session_start();
include 'koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Proses tambah user
if (isset($_POST['tambah'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $nama     = $_POST['nama'];

    $cek = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    if (mysqli_num_rows($cek) == 0) {
        mysqli_query($conn, "INSERT INTO users (username, password, nama_lengkap) 
                             VALUES ('$username', '$password', '$nama')");
    } else {
        echo "<script>alert('Username sudah digunakan!');</script>";
    }

    header("Location: admin.php");
    exit;
}

// Proses hapus user
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM users WHERE id=$id");
    header("Location: admin.php");
    exit;
}

// Ambil semua user
$result = mysqli_query($conn, "SELECT * FROM users ORDER BY id ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kelola Admin/User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
                <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="achievement.php" class="nav-link">Prestasi</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Galeri</a></li>
                <li class="nav-item"><a href="tournament.php" class="nav-link">Turnamen</a></li>
                <li class="nav-item"><a href="admin.php" class="nav-link active">Admin</a></li>
                <li class="nav-item"><a href="merchandise.php" class="nav-link">Merchandise</a></li>
            </ul>
            <span class="navbar-text text-white me-3">
                Halo, <?= $_SESSION['username']; ?>
            </span>
            <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container mt-5 mb-5">
    <h3 class="mb-4">Kelola User/Admin</h3>

    <!-- Form Tambah User -->
    <form method="post" class="row g-2 mb-4">
        <div class="col-md-3">
            <input type="text" name="username" class="form-control" placeholder="Username" required>
        </div>
        <div class="col-md-3">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="col-md-4">
            <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required>
        </div>
        <div class="col-md-2">
            <button type="submit" name="tambah" class="btn btn-success w-100">Tambah</button>
        </div>
    </form>

    <!-- Tabel User -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Username</th>
                <th>Nama Lengkap</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?= $row['username']; ?></td>
                    <td><?= $row['nama_lengkap']; ?></td>
                    <td>
                        <a href="admin.php?hapus=<?= $row['id']; ?>" 
                           class="btn btn-danger btn-sm"
                           onclick="return confirm('Hapus user ini?')">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
