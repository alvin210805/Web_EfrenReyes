<?php
session_start();

// Ambil file background (default: efren-banner.jpg)
$bgFile = file_exists("bg.txt") ? trim(file_get_contents("bg.txt")) : "goat_reyes.jpg";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Efren Reyes - Legenda Biliar Dunia</title>
    <!-- Bootstrap & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: url('images/<?= $bgFile ?>') no-repeat center center fixed;
            background-size: cover;
            color: white;
        }
        .overlay {
            background-color: rgba(0, 0, 0, 0.6);
            flex: 1; /* biar isi halaman fleksibel */
            padding-bottom: 50px;
        }
        .content-box {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 20px;
            border-radius: 15px;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.8);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">

<div class="overlay">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a href="index.php" class="nav-link active">Beranda</a></li>
                <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="achievement.php" class="nav-link">Prestasi</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Galeri</a></li>
                <li class="nav-item"><a href="tournament.php" class="nav-link">Turnamen</a></li>
                <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
                <li class="nav-item"><a href="merchandise.php" class="nav-link">Merchandise</a></li>
            </ul>
            <?php if (isset($_SESSION['username'])): ?>
                <span class="navbar-text text-white me-3">
                    Halo, <?= $_SESSION['username']; ?>
                </span>
                <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm btn-outline-light">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<section class="text-center py-5">
    <div class="container">
        <h1 class="display-4 fw-bold text-white">Efren "Bata" Reyes</h1>
        <p class="lead">Legenda hidup dunia biliar asal Filipina</p>
    </div>
</section>

<!-- Tentang -->
<section class="py-4">
    <div class="container">
        <div class="content-box mx-auto col-md-10 text-white">
            <h2 class="text-center mb-4">Tentang Efren Reyes</h2>
            <p>
    Efren "Bata" Reyes adalah salah satu pemain biliar paling terkenal sepanjang masa. Dikenal dengan julukan <strong>"The Magician"</strong>, Efren berasal dari Filipina dan telah memenangkan ratusan turnamen internasional. Gayanya yang tenang, penuh strategi, dan teknik sulap di atas meja biliar menjadikannya legenda dunia yang dihormati oleh pemain profesional di seluruh dunia.
</p>
<p>
    Lahir di Pampanga, Filipina, Efren mulai bermain biliar sejak usia muda di kedai milik pamannya. Dengan tekad dan kerja keras, ia mulai mengasah bakatnya hingga mampu bersaing di tingkat nasional dan kemudian internasional. Efren dikenal karena kemampuannya membaca permainan, kontrol bola yang luar biasa, dan kreativitas yang tak tertandingi dalam mengambil tembakan-tembakan sulit.
</p>
<p>
    Salah satu pencapaian terbaiknya adalah saat ia memenangkan <em>World Pool Championship</em> tahun 1999 dan menjadi pemain pertama yang menjuarai kejuaraan dunia versi WPA dan IPT. Di sepanjang kariernya, Efren tidak hanya dikenal sebagai pemain yang hebat, tetapi juga sebagai sosok yang rendah hati dan menjadi panutan bagi pemain muda di seluruh dunia.
</p>
<p>
    Hingga kini, Efren Reyes tetap dikenang sebagai ikon biliar sejati. Cerita perjalanannya bukan hanya tentang kemenangan, tetapi juga tentang ketekunan, kecerdikan, dan semangat pantang menyerah. Website ini didedikasikan untuk mengenang kejayaan dan warisan seorang maestro biliar sejati dari Asia untuk dunia.
</p>

        </div>
    </div>
</section>

</div> <!-- end overlay -->

<!-- Footer Sticky -->
<footer class="text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
