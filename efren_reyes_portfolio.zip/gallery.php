<?php
// gallery.php
session_start();

// Cek login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Galeri Efren Reyes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1;
        }
        .gallery-img {
            height: 200px;
            object-fit: cover;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }
        .gallery-img:hover {
            transform: scale(1.05);
        }
        .desc {
            color: #333;
            background: rgba(255,255,255,0.85);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.9rem;
            margin-top: 8px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
                <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="achievement.php" class="nav-link">Prestasi</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link active">Galeri</a></li>
                <li class="nav-item"><a href="tournament.php" class="nav-link">Turnamen</a></li>
                <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
                <li class="nav-item"><a href="merchandise.php" class="nav-link">Merchandise</a></li>
            </ul>
            <?php if (isset($_SESSION['username'])): ?>
                <span class="navbar-text text-white me-3">
                    Halo, <?= $_SESSION['username']; ?>
                </span>
                <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm btn-outline-light">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<main class="container my-5">
    <h2 class="mb-4 text-center">Galeri Efren "Bata" Reyes</h2>
    <div class="row g-4">
        <div class="col-md-4 text-center">
            <img src="efren_muda.jpg" class="img-fluid gallery-img shadow" alt="Efren Muda">
            <div class="desc">Efren Reyes di masa muda, menunjukkan bakatnya sejak usia belia di arena biliar lokal Filipina.</div>
        </div>
        <div class="col-md-4 text-center">
            <img src="efren_vs_harytanoe.jpeg" class="img-fluid gallery-img shadow" alt="Efren Juara Dunia">
            <div class="desc">Momen langka saat Efren bertanding dalam event eksibisi melawan tokoh Indonesia Hary Tanoe.</div>
        </div>
        <div class="col-md-4 text-center">
            <img src="efren_usopen.jpeg" class="img-fluid gallery-img shadow" alt="Efren Main One Pocket">
            <div class="desc">Efren saat berlaga di US Open Pool Championship, salah satu turnamen bergengsi dunia.</div>
        </div>
        <div class="col-md-4 text-center">
            <img src="efren_mosconi.jpg" class="img-fluid gallery-img shadow" alt="Efren Mosconi Cup">
            <div class="desc">Aksi Efren dalam Mosconi Cup, ajang bergengsi antara pemain Eropa dan Amerika.</div>
        </div>
        <div class="col-md-4 text-center">
            <img src="efren_dan_anji.jpg" class="img-fluid gallery-img shadow" alt="Efren dengan Dunia Manji">
            <div class="desc">Pertemuan unik antara Efren Reyes dan musisi Anji saat kunjungan ke Indonesia.</div>
        </div>
        <div class="col-md-4 text-center">
            <img src="efren_trophy.jpg" class="img-fluid gallery-img shadow" alt="Efren dan Penghargaan">
            <div class="desc">Efren memegang trofi kemenangan—simbol kejayaan dari ratusan turnamen internasional.</div>
        </div>
    </div>
</main>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
