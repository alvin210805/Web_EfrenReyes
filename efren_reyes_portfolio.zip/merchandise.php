<?php
// merchandise.php

session_start();

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Merchandise Efren Reyes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100 bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
                <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="achievement.php" class="nav-link">Prestasi</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Galeri</a></li>
                <li class="nav-item"><a href="tournament.php" class="nav-link">Turnamen</a></li>
                <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
                <li class="nav-item"><a href="merchandise.php" class="nav-link active">Merchandise</a></li>
            </ul>
            <span class="navbar-text text-white me-3">
                Halo, <?= $_SESSION['username']; ?>
            </span>
            <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container my-5">
    <h3 class="mb-4">Merchandise Resmi Efren Reyes</h3>
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="efren_shirt.jpeg" class="card-img-top" alt="Kaos Efren Reyes">
                <div class="card-body">
                    <h5 class="card-title">Kaos Efren Reyes</h5>
                    <p class="card-text">T-shirt eksklusif bergambar ilustrasi tembakan ajaib sang legenda biliar. Bahan cotton combed 30s, tersedia ukuran S-XL.</p>
                    <p class="fw-bold">Rp 120.000</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="predator_cue.jpeg" class="card-img-top" alt="Predator SP2 Revo">
                <div class="card-body">
                    <h5 class="card-title">Predator SP2 Revo</h5>
                    <p class="card-text">Cue/Stick Billiard andalan Efren Reyes yang selalu membawanya kepada kemenangan.</p>
                    <p class="fw-bold">Rp28.138.500</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="case_hp.webp" class="card-img-top" alt="Case HP bergambar Efren">
                <div class="card-body">
                    <h5 class="card-title">Case HP bergambar Efren</h5>
                    <p class="card-text">Casing Handphone eksklusif bergambar Efren Reyes untuk pecinta Olahraga Billiard serta penggemar berat Efren Reyes.</p>
                    <p class="fw-bold">Rp 50.000</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
