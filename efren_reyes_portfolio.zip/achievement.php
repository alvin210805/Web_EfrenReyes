<?php
// achievement.php

session_start();
include 'koneksi.php';

// Cek apakah user sudah login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Tambah data jika form disubmit
if (isset($_POST['tambah'])) {
    $tahun     = $_POST['tahun'];
    $judul     = $_POST['judul'];
    $deskripsi = $_POST['deskripsi'];

    $query = "INSERT INTO achievements (tahun, judul, deskripsi) VALUES ('$tahun', '$judul', '$deskripsi')";
    mysqli_query($conn, $query);
    header("Location: achievement.php");
    exit;
}

// Hapus data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($conn, "DELETE FROM achievements WHERE id=$id");
    header("Location: achievement.php");
    exit;
}

// Cek apakah tabel kosong, jika ya isi prestasi default
$cekData = mysqli_query($conn, "SELECT COUNT(*) as jumlah FROM achievements");
$data = mysqli_fetch_assoc($cekData);
if ($data['jumlah'] == 0) {
    mysqli_query($conn, "INSERT INTO achievements (tahun, judul, deskripsi) VALUES
        (1999, 'Juara Dunia 9-Ball WPA', 'Menjadi juara dunia 9-Ball pertama dari Asia'),
        (2001, 'Hall of Fame', 'Dianugerahi Hall of Fame oleh BCA (Billiard Congress of America)'),
        (2005, 'Juara 8-Ball IPT', 'Menang $500,000 di International Pool Tour'),
        (2009, 'Sea Games Gold', 'Menyumbangkan medali emas untuk Filipina'),
        (2010, 'The Legend Cup Champion', 'Menang turnamen legenda Asia vs Eropa')
    ");
}

// Proses pencarian
$cari = isset($_GET['cari']) ? $_GET['cari'] : '';
$sql = "SELECT * FROM achievements WHERE judul LIKE '%$cari%' ORDER BY tahun DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Prestasi Efren Reyes</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex flex-column min-vh-100">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
    <div class="container">
        <a class="navbar-brand fw-bold" href="#">Efren Reyes</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a href="index.php" class="nav-link">Beranda</a></li>
                <li class="nav-item"><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li class="nav-item"><a href="profile.php" class="nav-link">Profil</a></li>
                <li class="nav-item"><a href="achievement.php" class="nav-link active">Prestasi</a></li>
                <li class="nav-item"><a href="gallery.php" class="nav-link">Galeri</a></li>
                <li class="nav-item"><a href="tournament.php" class="nav-link">Turnamen</a></li>
                <li class="nav-item"><a href="admin.php" class="nav-link">Admin</a></li>
                <li class="nav-item"><a href="merchandise.php" class="nav-link">Merchandise</a></li>
            </ul>
            <?php if (isset($_SESSION['username'])): ?>
                <span class="navbar-text text-white me-3">
                    Halo, <?= $_SESSION['username']; ?>
                </span>
                <a href="logout.php" class="btn btn-sm btn-outline-light">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm btn-outline-light">Login</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<!-- Konten -->
<div class="container mt-4 mb-5 flex-grow-1">
    <h3 class="mb-4">Data Prestasi Efren Reyes</h3>

    <!-- Pencarian -->
    <form class="mb-3" method="get" action="achievement.php">
        <div class="input-group">
            <input type="text" name="cari" class="form-control" placeholder="Cari prestasi..." value="<?= htmlspecialchars($cari); ?>">
            <button class="btn btn-primary">Cari</button>
        </div>
    </form>

    <!-- Form Tambah -->
    <form method="post" class="row g-2 mb-4">
        <div class="col-md-2">
            <input type="number" name="tahun" class="form-control" placeholder="Tahun" required>
        </div>
        <div class="col-md-3">
            <input type="text" name="judul" class="form-control" placeholder="Judul" required>
        </div>
        <div class="col-md-4">
            <input type="text" name="deskripsi" class="form-control" placeholder="Deskripsi">
        </div>
        <div class="col-md-3">
            <button type="submit" name="tambah" class="btn btn-success w-100">Tambah Prestasi</button>
        </div>
    </form>

    <!-- Tabel Data -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Tahun</th>
                <th>Judul</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['tahun']; ?></td>
                <td><?= $row['judul']; ?></td>
                <td><?= $row['deskripsi']; ?></td>
                <td>
                    <a href="achievement.php?hapus=<?= $row['id']; ?>" 
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3 mt-auto">
    <div class="container">
        &copy; <?= date('Y'); ?> Efren Reyes Portfolio | Dibuat oleh Alvin Khair (2023230039)
    </div>
</footer>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
