<?php
// logout.php

// Mulai dan hancurkan session
session_start();
session_destroy();

// Arahkan kembali ke login
header("Location: login.php");
?>
