<?php
// koneksi.php

// Buat koneksi ke database
$host = "localhost";           // Host database, biasanya 'localhost'
$user = "root";                // Username MySQL
$pass = "";                    // Password MySQL (kosong di XAMPP)
$db   = "db_efren";            // Nama database

// Lakukan koneksi
$conn = mysqli_connect($host, $user, $pass, $db);

// Cek apakah koneksi berhasil
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>
